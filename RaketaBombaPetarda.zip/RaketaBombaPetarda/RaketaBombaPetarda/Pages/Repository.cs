﻿namespace RaketaBombaPetarda.Pages
{
    public class Repository
    {
        public int Id { get; set; } 
        public string Name { get; set; }
        public string Owner { get; set; }
        public int Stargazers { get; set; }
        public int Watchers { get; set; }
        public string RepoUrl { get; set; }
    }

}
