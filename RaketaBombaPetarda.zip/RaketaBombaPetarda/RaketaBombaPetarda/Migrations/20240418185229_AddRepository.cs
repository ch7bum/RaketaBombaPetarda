﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RaketaBombaPetarda.Migrations
{
    /// <inheritdoc />
    public partial class AddRepository : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
