using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using RaketaBombaPetarda.Data;
using RaketaBombaPetarda.Pages;
using System.Collections;

public class IndexModel : PageModel
{
    private readonly HttpClient _httpClient;
    private readonly ApplicationDbContext _context;

    public IndexModel(IHttpClientFactory httpClientFactory, ApplicationDbContext context)
    {
        _httpClient = httpClientFactory.CreateClient("GitHubClient");
        _context = context;
    }

    public List<Repository> Repositories { get; set; } = new List<Repository>();

    public async Task OnGetAsync(string searchTerm)
    {
        if (!string.IsNullOrEmpty(searchTerm))
        {
            var response = await _httpClient.GetAsync($"https://api.github.com/search/repositories?q={searchTerm}");
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<dynamic>(content);
                Repositories = ((IEnumerable)result.items).Cast<dynamic>().Select(item => new Repository
                {
                    Name = item.name,
                    Owner = item.owner.login,
                    Stargazers = item.stargazers_count,
                    Watchers = item.watchers_count,
                    RepoUrl = item.html_url
                }).ToList();
            }
        }
    }

    public async Task<IActionResult> OnPostSaveAndVisitGitHubAsync(string repositoryJson)
    {
        if (!string.IsNullOrEmpty(repositoryJson))
        {
            var repo = System.Text.Json.JsonSerializer.Deserialize<Repository>(repositoryJson);
            if (repo != null && !string.IsNullOrEmpty(repo.RepoUrl))
            {
                // ���������� � ���� ������
                _context.Add(repo);
                await _context.SaveChangesAsync();

                // ��������������� �� GitHub
                return Redirect(repo.RepoUrl);
            }
        }
        return Page(); // ������������ �� ������� ��������, ���� ���-�� ����� �� ���
    }

}
