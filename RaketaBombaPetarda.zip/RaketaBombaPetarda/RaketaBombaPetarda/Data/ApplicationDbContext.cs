﻿using Microsoft.EntityFrameworkCore;
using RaketaBombaPetarda.Pages;
namespace RaketaBombaPetarda.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Repository> Repositories { get; set; }
    }

    public class RepositoryData
    {
        public int Id { get; set; }
        public string JsonData { get; set; }
    }
}